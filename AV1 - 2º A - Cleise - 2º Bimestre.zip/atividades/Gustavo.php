<?php

	$numero = $_POST['numero'];
	
	$quadrado = pow($numero,2);
	
	echo "O quadrado de $numero é: ".$quadrado;


?>