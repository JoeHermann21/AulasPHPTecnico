<?php
	$dolar = $_POST['dolar'];
	
	function conversao ($dolar)
	{
		return  $dolar*5.19;
	}
	
	echo "Voce Tem $$dolar Dolares, Em Reais : R$".conversao($dolar);
?>