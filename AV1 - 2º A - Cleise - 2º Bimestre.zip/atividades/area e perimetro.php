<?php 
    $b1 = $_POST [ 'b1'];
	$a1 = $_POST [ 'a1' ];
	
	$area = $b1*$a1;
	$perimetro = 2*($b1+$a1);
	
	echo "A area é:" .$area; print "<br>";

	echo "O perimetro é:" .$perimetro;
	
	
?>