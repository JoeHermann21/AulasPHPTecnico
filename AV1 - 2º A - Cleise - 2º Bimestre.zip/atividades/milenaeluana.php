<?php
function kmh_to_mnh($v){

   $mnH = $v / 1.852;

   return $mnH.'mn/h';
}

echo kmh_to_mnh(50);
?>