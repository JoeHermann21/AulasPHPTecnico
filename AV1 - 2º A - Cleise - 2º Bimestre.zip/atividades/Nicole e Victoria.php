<?php
$raio = $_GET["raio"];
echo "o raio da circunferencia : ".$raio*3.1416;
?>