<?php
	$mes = $_POST['mes'];
	
	if($mes == 1){
		echo "<h1>Mês de Janeiro<h1></br><h2>O mês de janeiro é também um mês simbólico para muitas pessoas, talvez por ser o primeiro do ano, ele representa recomeço. 
		É como se a virada do ano terminasse um ciclo e começasse um novo ciclo. Para outros é apenas um mês comum como qualquer outro.<h2>";
	}elseif($mes == 2){
		echo "<h1>Mês de Fevereiro<h1></br><h2>A probabilidade de uma pessoa nascer em 29 de fevereiro, é de 1 a cada 1.461 nascimentos.<h2>";
	}elseif($mes == 3){
		echo "<h1>Mês de Março<h1></br><h2>Em inglês antigo, um nome para o mês de março era Hlyda, que significa alto, 
		possivelmente por causa dos fortes ventos de março.<h2>";
	}elseif($mes == 4){
		echo "<h1>Mês de Abril<h1></br><h2>Entre os trotes de abril, um dos mais populares era o anúncio de casamentos falsos, 
		marcados para o dia 1º. Arruaceiros também pregavam cartazes com supostos editos reais de conteúdo jocoso.<h2>";
	}elseif($mes == 5){
		echo "<h1>Mês de Maio<h1></br><h2>Mês da estação das colheitas, 
		sendo uma época muito importante para os costumes populares, é celebrado com muitas flores, em homenagem à natureza que refloresce<h2>";
	}elseif($mes == 6){
		echo "<h1>Mês de Junho<h1></br><h2>O mês que fecha o primeiro semestre do ano traz comemorações como o Dia Mundial do Meio Ambiente. 
		Em meio às festividades ligadas às tradições religiosas das Festas Juninas, o mês de junho também celebra o Dia Mundial do Meio Ambiente, 
		o Dia Internacional do Aperto de Mão e o Dia do Cinema Brasileiro.<h2>";
	}elseif($mes == 7){
		echo "<h1>Mês de Julho<h1></br><h2>É o quinto mês do ano no Calendário Romano. O nome faz referência ao imperador Júlio Cesar, 
		mesmo período em que ele nasceu. Antes disso o período era chamado de Quintilis.<h2>";
	}elseif($mes == 8){
		echo "<h1>Mês de Agosto<h1></br><h2>o Brasil é um dos poucos países que comemora o Dia dos Pais em agosto. 
		Na maioria dos países, a data é celebrada em junho.<h2>";
	}elseif($mes == 9){
		echo "<h1>Mês de Setembro<h1></br><h2>Em 1º de setembro de 1985, após muita procura, foram encontrados os destroços do Titanic, que naufragou em 1912.<h2>";
	}elseif($mes == 10){
		echo "<h1>Mês de Outubro<h1></br><h2>Em outubro, Jorge Amado lançou seu primeiro romance, 
		“O País do Carnaval”, em 1931, coincidentemente, mesma data em que o Cristo Redentor foi inaugurado no Corcovado<h2>";
	}elseif($mes == 11){
		echo "<h1>Mês de Novembro<h1></br><h2>dia 27 de novembro é celebrado o Dia Nacional de Combate ao Câncer, 
		uma ação voltada a todos os tipos de manifestação dessa doença.<h2>";
	}else{
		echo "<h1>Mês de Dezembro<h1></br><h2>28 de dezembro é considerado por alguns como sendo o dia mais azarado do ano.<h2>";
	}
?>