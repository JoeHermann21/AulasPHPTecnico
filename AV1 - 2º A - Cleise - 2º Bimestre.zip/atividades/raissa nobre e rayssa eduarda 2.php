<?php
$salario = $_GET["salario"];
echo "você ganha: ".$salario/1.212."salários mínimos";
?>