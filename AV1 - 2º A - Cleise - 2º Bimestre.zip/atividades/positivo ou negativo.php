<?php
$valor = $_POST["valor"];
 
if($valor < 0){
   echo "Negativo";
}else{
   echo "Positivo";
}
?>
