<?php
	$kg = $_POST['kg'];
	
	function conversao ($kg)
	{
		return  $kg*2.20462;
	}
	
	echo "Voce Tem $kg quilograma, Em libra : ".conversao($kg);
?>