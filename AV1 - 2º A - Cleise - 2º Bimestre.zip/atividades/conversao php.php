<?php 
     $celsius = $_POST ['celsius'];
	 function conversao ($celsius)
	 {
	   return ($celsius*9/5) + 32;
	 }
	 echo "<span style='color:#FF0099;'>A temperatura de $celsius °C em °F é: </span>".conversao ($celsius);
?>
