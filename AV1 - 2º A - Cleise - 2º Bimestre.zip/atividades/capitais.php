<?php

	$paises = $_POST['paises'];
	
	if ($paises == "Argentina"){
		echo "Buenos Aires";
	}
	
	if ($paises == "Bolívia"){
		echo "La Paz";
	}
	
	if ($paises == "Brasil"){
		echo "Brasília";
	}
	
	if ($paises == "Chile"){
		echo "Santiago";
	}
	
	if ($paises == "Colômbia"){
		echo "Bogotá";
	}
	
	if ($paises == "Equador"){
		echo "Quito";
	}
	
	if ($paises == "Paraguai"){
		echo "Assunção";
	}
	
	if ($paises == "Peru"){
		echo "Lima";
	}
	
	if ($paises == "Uruguai"){
		echo "Montevidéu";
	}
	
	if ($paises == "Venezuela"){
		echo "Caracas";
	}
	
?>	