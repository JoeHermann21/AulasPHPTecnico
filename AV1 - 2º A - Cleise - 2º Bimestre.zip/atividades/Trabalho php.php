<?php

    $Professores = $_POST['Professores'];
	
	if ($Professores == "Tiago"){
		echo "Sociologia";
	}
	
	if ($Professores == "Patricia"){
		echo "Português";
	}
	
	if ($Professores == "Marcia"){
		echo "Biologia";
	}
	
	if ($Professores == "Flavia"){
		echo "Física";
	}
	
	if ($Professores == "Bruno"){
		echo "Química";
	}
	
	if ($Professores == "Paulo"){
		echo "Filosofia";
	}
	
	if ($Professores == "Larissa"){
		echo "Matemática";
	}
	
	if ($Professores == "Cintia"){
		echo "História";
	}
	
	if ($Professores == "Daiana"){
		echo "Geografia";
	}
		
?>