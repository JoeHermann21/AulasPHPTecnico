<?php
        $raio1 = $_POST['raio1'];
    		 
        function atividade3 ($raio1)
        {
		
			return 2*3.14*$raio1;
		 
        }
		
    echo "a circuferencia do numero <br> $raio1 <br>". atividade3 ($raio1);
	
?>