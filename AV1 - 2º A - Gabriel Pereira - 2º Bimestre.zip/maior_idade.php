<?php
 $idade = $_POST['idade'];
  if($idade >= 18){
    echo "Você é maior de 18 e tem {$idade} Anos";
  }else{
    echo "Você não é maior de 18 e tem {$idade} Anos";
	
  }
?>                                                