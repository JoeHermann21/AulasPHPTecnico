<?php
    
	$reais=$_POST['reais'];
	
	function trabaio ($reais)
	{
		return $reais *5.15; 
    }
	
	echo "O valor convertido em dólar ".$reais." é ".trabaio($reais). "$"; 
	
	
?>

