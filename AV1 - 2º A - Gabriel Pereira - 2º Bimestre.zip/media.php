<?php 
  $num1 = $_GET['num1'];
  $num2 = $_GET['num2'];
  
  $media = ($num1 + $num2)/2;
  
  echo "Média: $media";
 ?>
