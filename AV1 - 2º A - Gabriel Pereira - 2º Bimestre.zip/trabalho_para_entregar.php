<?php
	$valor = $_POST['valor']; //Valor de entrada

	if($valor > 0){
		$resultado = "Valor positivo";
	}elseif($valor < 0){
		$resultado = "Valor Negativo";
	}else{
		$resultado = "Igual a Zero";
	}

echo $resultado;
?>